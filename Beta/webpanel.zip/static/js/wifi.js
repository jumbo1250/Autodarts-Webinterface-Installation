/*
 * Copyright (c) 2026 Peter Rottmann
 * All rights reserved.
 * Proprietary and not open source.
 * No use, modification, distribution, publication, sublicensing,
 * or commercial use without prior express written permission.
 * Applies only to parts created by Peter Rottmann.
 * Third-party components remain under their respective licenses.
 * Provided "as is", without warranty.
 */

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('wifiForm');
  if (!form) return;

  form.addEventListener('submit', function () {
    const msg = document.getElementById('workmsg');
    if (msg) msg.style.display = 'block';
    const btn = form.querySelector('button[type="submit"]');
    if (btn) {
      btn.disabled = true;
      btn.textContent = t('wifi.please_wait', 'Bitte warten…');
    }
  });

  const pick = document.getElementById('ssidPick');
  const ssidInput = document.getElementById('ssid');
  const manual = document.getElementById('ssidManual');
  const refreshBtn = document.getElementById('wifiRefresh');
  const ssidLabel = document.getElementById('ssidLabel');

  function setManualMode(on) {
    if (on) {
      if (pick) {
        pick.style.display = 'none';
        pick.required = false;
      }
      if (refreshBtn) refreshBtn.style.display = 'none';
      if (ssidLabel) ssidLabel.style.display = '';
      if (ssidInput) {
        ssidInput.style.display = '';
        ssidInput.readOnly = false;
        ssidInput.required = true;
        ssidInput.focus();
      }
    } else {
      if (pick) {
        pick.style.display = '';
        pick.required = true;
      }
      if (refreshBtn) refreshBtn.style.display = '';
      if (ssidLabel) ssidLabel.style.display = 'none';
      if (ssidInput) {
        ssidInput.style.display = 'none';
        ssidInput.readOnly = true;
        ssidInput.required = false;
      }
    }
  }

  async function loadWifi(rescan) {
    if (!pick) return;
    pick.innerHTML = `<option>${t('wifi.searching_networks', 'Suche WLANs…')}</option>`;
    if (refreshBtn) {
      refreshBtn.disabled = true;
      refreshBtn.textContent = '⏳';
    }

    try {
      const url = rescan ? '/api/wifi/scan?trigger=1' : '/api/wifi/scan';
      const r = await fetch(url, { cache: 'no-store' });
      const j = await r.json();
      if (!j.ok) {
        throw new Error(j.msg || t('wifi.scan_failed', 'Scan fehlgeschlagen'));
      }

      pick.innerHTML = '';
      const nets = j.networks || [];

      if (nets.length === 0) {
        pick.innerHTML = `<option value="">${t('wifi.no_ssids_found', '(Keine WLANs gefunden – nochmal Refresh versuchen)')}</option>`;
        setManualMode(false);
        if (manual) manual.checked = false;
        if (refreshBtn) {
          refreshBtn.disabled = false;
          refreshBtn.textContent = t('wifi.refresh', 'Refresh');
        }
        return;
      }

      const ph = document.createElement('option');
      ph.value = '';
      ph.textContent = t('wifi.select_network_placeholder', '(WLAN auswählen…)');
      pick.appendChild(ph);

      for (const n of nets) {
        const opt = document.createElement('option');
        opt.value = n.ssid;
        const sec = n.security ? n.security : t('wifi.security_open', 'open');
        const star = n.in_use ? '★ ' : '';
        opt.textContent = `${star}${n.ssid} (${n.signal}%, ${sec})`;
        if (n.in_use) opt.selected = true;
        pick.appendChild(opt);
      }

      if (pick.value) {
        ssidInput.value = pick.value;
      } else {
        const sel = pick.querySelector('option[selected]');
        if (sel && sel.value) {
          pick.value = sel.value;
          ssidInput.value = sel.value;
        }
      }

      setManualMode(false);
      if (manual) manual.checked = false;
    } catch (e) {
      if (pick) {
        pick.innerHTML = `<option value="">${t('wifi.scan_failed_manual', '(Scan fehlgeschlagen – manuell eingeben)')}</option>`;
      }
      console.log(e);
    } finally {
      if (refreshBtn) {
        refreshBtn.disabled = false;
        refreshBtn.textContent = t('wifi.refresh', 'Refresh');
      }
    }
  }

  if (manual) {
    manual.addEventListener('change', () => setManualMode(manual.checked));
  }

  if (pick) {
    pick.addEventListener('change', () => {
      ssidInput.value = pick.value || '';
    });
  }

  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => loadWifi(true));
  }
	
	
	const passwordInput = document.getElementById('password');
	const showPassword = document.getElementById('showPassword');

	
	showPassword.addEventListener("change", function () {
	  if (this.checked) {
		passwordInput.type = "text";
	  } else {
		passwordInput.type = "password";
	  }
	});
	


  function startWifiRebootModal() {
    const modal = document.getElementById('wifiRebootModal');
    if (!modal) return;

    document.body.classList.add('wifi-modal-open');

    const titleEl = document.getElementById('wifiRebootTitle');
    const mainEl = document.getElementById('wifiRebootMain');
    const helpEl = document.getElementById('wifiRebootHelp');
    const countdownEl = document.getElementById('wifiRebootCountdown');
    const cancelBtn = document.getElementById('wifiRebootCancel');
    const cancelMsg = document.getElementById('wifiRebootCancelMsg');
    const cancelUrl = modal.dataset.cancelUrl || '/wifi/reboot/cancel';
    let remaining = parseInt(modal.dataset.countdown || '10', 10);
    let finished = false;

    if (!Number.isFinite(remaining) || remaining < 1) remaining = 10;

    function render() {
      if (countdownEl) countdownEl.textContent = String(Math.max(0, remaining));
    }

    render();
    const timer = window.setInterval(() => {
      remaining -= 1;
      render();
      if (remaining <= 0) {
        finished = true;
        window.clearInterval(timer);
        if (cancelBtn) cancelBtn.disabled = true;
        if (titleEl) titleEl.textContent = 'System wird neu gestartet';
        if (mainEl) mainEl.textContent = 'Bitte kurz warten.';
        if (helpEl) helpEl.textContent = 'Nach dem Neustart wieder mit „Autodartsinstall1“ verbinden.';
      }
    }, 1000);

    if (cancelBtn) {
      cancelBtn.addEventListener('click', async () => {
        if (finished) return;
        cancelBtn.disabled = true;
        const oldText = cancelBtn.textContent;
        cancelBtn.textContent = 'Bitte warten…';
        try {
          const r = await fetch(cancelUrl, { method: 'POST', cache: 'no-store' });
          const j = await r.json().catch(() => ({}));
          if (!r.ok || j.ok === false) {
            throw new Error(j.msg || 'Abbrechen fehlgeschlagen');
          }

          finished = true;
          window.clearInterval(timer);
          if (titleEl) titleEl.textContent = 'Neustart abgebrochen';
          if (mainEl) mainEl.textContent = 'Der WLAN-Kanal wird jetzt gewechselt.';
          if (helpEl) helpEl.textContent = 'Die Verbindung trennt sich gleich. Danach wieder mit „Autodartsinstall1“ verbinden.';
          if (cancelMsg) {
            cancelMsg.textContent = j.msg || 'Neustart abgebrochen. Bitte nach dem Kanalwechsel erneut verbinden.';
            cancelMsg.style.display = 'block';
          }
          cancelBtn.textContent = 'Abgebrochen';
        } catch (e) {
          cancelBtn.disabled = false;
          cancelBtn.textContent = oldText;
          if (cancelMsg) {
            cancelMsg.textContent = e && e.message
              ? e.message
              : 'Abbrechen konnte nicht bestätigt werden.';
            cancelMsg.style.display = 'block';
          }
        }
      });
    }
  }

  startWifiRebootModal();
  loadWifi();
});