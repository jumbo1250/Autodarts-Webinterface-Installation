(() => {
  const STYLE_ID = 'autodarts-theme-style';
  const CONTROL_HOST_ID = 'autodarts-theme-control-host';
  const STORAGE_CSS_KEY = 'autodartsThemeCachedCss';
  const STORAGE_SOURCE_KEY = 'autodartsThemeCachedSource';
  const STORAGE_LIBRARY_KEY = 'autodartsThemeLibraryV1';
  const STORAGE_SELECTED_KEY = 'autodartsThemeSelectedId';
  const STORAGE_MODE_KEY = 'autodartsThemeControlMode';
  const STORAGE_ZOOM_KEY = 'autodartsThemeZoom';
  const STORAGE_LANG_KEY = 'autodartsThemeUiLanguage';
  const STORAGE_POS_KEY = 'autodartsThemeControlPosition';
  const APPLY_INTERVAL_MS = 10000;
  const RETRY_DELAYS_MS = [0, 80, 250, 700, 1500, 3200];

  let lastAppliedCss = '';
  let lastAppliedSource = '';
  let lastKnownHref = location.href;
  let refreshTimer = null;
  let observer = null;
  let navPatched = false;
  let controlHost = null;
  let controlShadow = null;
  let lastUiState = null;
  let currentUiLanguage = 'de';
  let controlPosition = { xRatio: 1, yRatio: 1 };
  let suppressEyeClick = false;
  let zoomApplyTimer = null;
  const ZOOM_APPLY_DELAY_MS = 350;

  function debug(...args) {
    console.debug('Autodarts Themes:', ...args);
  }

  function getTargetNode() {
    return document.head || document.documentElement;
  }

  function ensureStyleElement() {
    let styleEl = document.getElementById(STYLE_ID);
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = STYLE_ID;
      styleEl.type = 'text/css';
      styleEl.setAttribute('data-autodarts-theme', 'active');
    }

    const target = getTargetNode();
    if (target && styleEl.parentNode !== target) {
      target.appendChild(styleEl);
    }

    return styleEl;
  }

  function keepStyleLast() {
    const target = getTargetNode();
    const styleEl = document.getElementById(STYLE_ID);
    if (!target || !styleEl) return;

    if (target.lastElementChild !== styleEl) {
      target.appendChild(styleEl);
    }
  }

  function normalizeCss(cssText) {
    return String(cssText || '').replace(/^\uFEFF/, '').trim();
  }

  function applyCss(cssText, sourceUrl = '') {
    const normalized = normalizeCss(cssText);
    const styleEl = ensureStyleElement();

    if (styleEl.textContent !== normalized) {
      styleEl.textContent = normalized;
    }

    styleEl.setAttribute('data-source-url', sourceUrl || '');
    keepStyleLast();

    lastAppliedCss = normalized;
    lastAppliedSource = sourceUrl || '';
  }

  async function loadCachedCss() {
    try {
      const data = await chrome.storage.local.get([STORAGE_CSS_KEY, STORAGE_SOURCE_KEY]);
      return {
        css: normalizeCss(data[STORAGE_CSS_KEY] || ''),
        sourceUrl: typeof data[STORAGE_SOURCE_KEY] === 'string' ? data[STORAGE_SOURCE_KEY] : ''
      };
    } catch (error) {
      debug('cache read failed', error);
      return { css: '', sourceUrl: '' };
    }
  }

  function sendMessage(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) {
            debug('runtime message failed', chrome.runtime.lastError.message);
            resolve(null);
            return;
          }
          resolve(response || null);
        });
      } catch (error) {
        debug('sendMessage threw', error);
        resolve(null);
      }
    });
  }

  function requestBackgroundCss(force = false) {
    return sendMessage({ type: 'autodarts-theme:refresh-css', force });
  }

  async function refreshTheme(force = false) {
    if (!force && lastAppliedCss) {
      applyCss(lastAppliedCss, lastAppliedSource);
    }

    const result = await requestBackgroundCss(force);

    // A successful panel response with empty CSS is authoritative and means
    // "Default / theme off". A failed panel request must not clear a cached theme.
    if (result && result.ok && typeof result.css === 'string' && (normalizeCss(result.css) || result.authoritative)) {
      applyCss(result.css, result.sourceUrl || '');
      return result;
    }

    const cached = await loadCachedCss();
    if (cached.css) {
      applyCss(cached.css, cached.sourceUrl);
    } else if (lastAppliedCss) {
      applyCss(lastAppliedCss, lastAppliedSource);
    } else {
      ensureStyleElement();
      keepStyleLast();
    }
    return { ok: true, css: cached.css, sourceUrl: cached.sourceUrl, fromCache: true, stale: true };
  }

  function scheduleBurst(reason) {
    RETRY_DELAYS_MS.forEach((delay) => {
      window.setTimeout(() => {
        refreshTheme(delay > 0).catch((error) => debug(`refresh failed after ${reason}`, error));
      }, delay);
    });
  }

  function startObservers() {
    const root = document.documentElement;
    if (!root) {
      window.setTimeout(startObservers, 25);
      return;
    }

    if (!observer) {
      observer = new MutationObserver(() => {
        keepStyleLast();
        if (location.href !== lastKnownHref) {
          lastKnownHref = location.href;
          scheduleBurst('mutation-navigation');
        }
      });

      observer.observe(root, {
        childList: true,
        subtree: true
      });
    }

    if (!refreshTimer) {
      refreshTimer = window.setInterval(() => {
        if (document.visibilityState === 'visible') {
          refreshTheme(true).catch((error) => debug('interval refresh failed', error));
        }
      }, APPLY_INTERVAL_MS);
    }
  }

  function patchHistoryNavigation() {
    if (navPatched) return;
    navPatched = true;

    const wrap = (original) => function wrappedHistoryMethod(...args) {
      const result = original.apply(this, args);
      window.setTimeout(() => {
        if (location.href !== lastKnownHref) {
          lastKnownHref = location.href;
          scheduleBurst('history-navigation');
        }
      }, 0);
      return result;
    };

    history.pushState = wrap(history.pushState);
    history.replaceState = wrap(history.replaceState);
    window.addEventListener('popstate', () => {
      if (location.href !== lastKnownHref) {
        lastKnownHref = location.href;
        scheduleBurst('popstate');
      }
    });
  }

  function normalizeUiLanguage(value) {
    return String(value || '').toLowerCase() === 'en' ? 'en' : 'de';
  }

  function uiTexts(lang = currentUiLanguage) {
    if (normalizeUiLanguage(lang) === 'en') {
      return {
        title: 'Autodarts Theme', theme: 'Theme', zoom: 'Browser zoom', author: 'Author',
        modes: 'Game modes', resolution: 'Resolution', unknown: 'not specified', close: 'Close',
        reset: '100%', legacy: 'Web panel', local: 'Browser', defaultName: 'Default (off)',
        noThemes: 'No themes synchronized yet', drag: 'Drag to move', legacyActive: 'Web panel · active'
      };
    }
    return {
      title: 'Autodarts Theme', theme: 'Theme', zoom: 'Browser-Zoom', author: 'Autor',
      modes: 'Spielmodi', resolution: 'Auflösung', unknown: 'nicht angegeben', close: 'Schließen',
      reset: '100%', legacy: 'Webpanel', local: 'Browser', defaultName: 'Default (aus)',
      noThemes: 'Noch keine Themes synchronisiert', drag: 'Zum Verschieben ziehen', legacyActive: 'Webpanel · aktiv'
    };
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function normalizedPosition(raw) {
    const x = Number(raw?.xRatio);
    const y = Number(raw?.yRatio);
    return {
      xRatio: Number.isFinite(x) ? clamp(x, 0, 1) : 1,
      yRatio: Number.isFinite(y) ? clamp(y, 0, 1) : 1
    };
  }

  async function loadControlPreferences() {
    try {
      const data = await chrome.storage.local.get([STORAGE_LANG_KEY, STORAGE_POS_KEY]);
      currentUiLanguage = normalizeUiLanguage(data[STORAGE_LANG_KEY] || 'de');
      controlPosition = normalizedPosition(data[STORAGE_POS_KEY]);
    } catch (error) {
      debug('control preferences read failed', error);
    }
    applyControlPosition();
    applyUiLanguage();
  }

  function eyeMetrics() {
    const size = 48;
    const margin = 12;
    return {
      size,
      margin,
      maxX: Math.max(margin, window.innerWidth - size - margin),
      maxY: Math.max(margin, window.innerHeight - size - margin)
    };
  }

  function ratioToPixel(ratio, maxValue, margin) {
    const span = Math.max(0, maxValue - margin);
    return margin + (span * clamp(Number(ratio) || 0, 0, 1));
  }

  function pixelToRatio(pixel, maxValue, margin) {
    const span = Math.max(1, maxValue - margin);
    return clamp((pixel - margin) / span, 0, 1);
  }

  function applyControlPosition() {
    if (!controlShadow) return;
    const eye = controlShadow.getElementById('eye');
    if (!eye) return;
    const m = eyeMetrics();
    const left = ratioToPixel(controlPosition.xRatio, m.maxX, m.margin);
    const top = ratioToPixel(controlPosition.yRatio, m.maxY, m.margin);
    eye.style.left = `${Math.round(left)}px`;
    eye.style.top = `${Math.round(top)}px`;
    positionOpenPanel();
  }

  async function saveControlPosition(left, top) {
    const m = eyeMetrics();
    controlPosition = {
      xRatio: pixelToRatio(clamp(left, m.margin, m.maxX), m.maxX, m.margin),
      yRatio: pixelToRatio(clamp(top, m.margin, m.maxY), m.maxY, m.margin)
    };
    try {
      await chrome.storage.local.set({ [STORAGE_POS_KEY]: controlPosition });
    } catch (error) {
      debug('control position save failed', error);
    }
  }

  function positionOpenPanel() {
    if (!controlShadow) return;
    const eye = controlShadow.getElementById('eye');
    const panel = controlShadow.getElementById('panel');
    if (!eye || !panel || !panel.classList.contains('open')) return;

    const margin = 12;
    const gap = 10;
    const eyeRect = eye.getBoundingClientRect();
    const panelRect = panel.getBoundingClientRect();
    const panelWidth = Math.min(panelRect.width || 570, Math.max(280, window.innerWidth - (margin * 2)));
    const panelHeight = Math.min(panelRect.height || 250, Math.max(120, window.innerHeight - (margin * 2)));

    let left = eyeRect.left;
    if (left + panelWidth > window.innerWidth - margin) {
      left = eyeRect.right - panelWidth;
    }
    left = clamp(left, margin, Math.max(margin, window.innerWidth - panelWidth - margin));

    let top = eyeRect.bottom + gap;
    if (top + panelHeight > window.innerHeight - margin) {
      top = eyeRect.top - panelHeight - gap;
    }
    top = clamp(top, margin, Math.max(margin, window.innerHeight - panelHeight - margin));

    panel.style.left = `${Math.round(left)}px`;
    panel.style.top = `${Math.round(top)}px`;
  }

  function applyUiLanguage() {
    if (!controlShadow) return;
    const t = uiTexts();
    const title = controlShadow.getElementById('uiTitle');
    const themeLabel = controlShadow.getElementById('themeLabel');
    const zoomLabel = controlShadow.getElementById('zoomLabel');
    const authorKey = controlShadow.getElementById('authorKey');
    const modesKey = controlShadow.getElementById('modesKey');
    const resolutionKey = controlShadow.getElementById('resolutionKey');
    const close = controlShadow.getElementById('close');
    const eye = controlShadow.getElementById('eye');
    const deButton = controlShadow.getElementById('langDe');
    const enButton = controlShadow.getElementById('langEn');

    if (title) title.textContent = t.title;
    if (themeLabel) themeLabel.textContent = t.theme;
    if (zoomLabel) zoomLabel.textContent = t.zoom;
    if (authorKey) authorKey.textContent = `${t.author}:`;
    if (modesKey) modesKey.textContent = `${t.modes}:`;
    if (resolutionKey) resolutionKey.textContent = `${t.resolution}:`;
    if (close) {
      close.title = t.close;
      close.setAttribute('aria-label', t.close);
    }
    if (eye) {
      eye.title = `${t.title} · ${t.drag}`;
      eye.setAttribute('aria-label', `${t.title} · ${t.drag}`);
    }
    if (deButton) deButton.classList.toggle('active', currentUiLanguage === 'de');
    if (enButton) enButton.classList.toggle('active', currentUiLanguage === 'en');

    if (lastUiState) renderControlState(lastUiState);
  }

  async function setUiLanguage(lang) {
    currentUiLanguage = normalizeUiLanguage(lang);
    try {
      await chrome.storage.local.set({ [STORAGE_LANG_KEY]: currentUiLanguage });
    } catch (error) {
      debug('language save failed', error);
    }
    applyUiLanguage();
  }

  function ensureControlUi() {
    if (controlHost && controlShadow) return;
    const parent = document.documentElement || document.body;
    if (!parent) {
      window.setTimeout(ensureControlUi, 50);
      return;
    }

    controlHost = document.getElementById(CONTROL_HOST_ID);
    if (!controlHost) {
      controlHost = document.createElement('div');
      controlHost.id = CONTROL_HOST_ID;
      parent.appendChild(controlHost);
    }

    // Full-viewport host with pointer-events disabled is very robust on Chromium:
    // only the eye and the panel themselves receive mouse/touch input.
    controlHost.style.display = 'none';
    controlHost.style.position = 'fixed';
    controlHost.style.inset = '0';
    controlHost.style.width = '100vw';
    controlHost.style.height = '100vh';
    controlHost.style.zIndex = '2147483647';
    controlHost.style.pointerEvents = 'none';

    controlShadow = controlHost.shadowRoot || controlHost.attachShadow({ mode: 'open' });
    controlShadow.innerHTML = `
      <style>
        :host { all: initial; }
        * { box-sizing: border-box; }
        #eye {
          position: fixed; left: 12px; top: 12px; z-index: 2;
          width: 48px; height: 48px; border: 1px solid rgba(255,255,255,.28); border-radius: 50%;
          background: rgba(17,20,28,.94); color: #fff; cursor: grab; display: flex; align-items: center;
          justify-content: center; box-shadow: 0 10px 30px rgba(0,0,0,.38); padding: 0;
          pointer-events: auto; touch-action: none; user-select: none; -webkit-user-select: none;
          -webkit-tap-highlight-color: transparent;
        }
        #eye:hover { background: rgba(35,40,52,.98); }
        #eye.dragging { cursor: grabbing; }
        #eye.hidden { visibility: hidden; pointer-events: none; }
        #eye svg { width: 25px; height: 25px; fill: none; stroke: currentColor; stroke-width: 1.8; pointer-events:none; }
        #panel {
          position: fixed; left: 12px; top: 70px; z-index: 3; display: none;
          width: min(570px, calc(100vw - 24px)); max-height: calc(100vh - 24px); overflow: auto;
          padding: 14px; border: 1px solid rgba(255,255,255,.22); border-radius: 14px;
          background: rgba(17,20,28,.97); color: #f7f7f8; box-shadow: 0 18px 55px rgba(0,0,0,.48);
          font-family: Arial, sans-serif; font-size: 14px; line-height: 1.35; pointer-events: auto;
          overscroll-behavior: contain;
        }
        #panel.open { display: block; }
        .header { display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:12px; }
        .title { font-size:17px; font-weight:700; }
        .headerActions { display:flex; align-items:center; gap:7px; }
        .langSwitch { display:flex; border:1px solid rgba(255,255,255,.20); border-radius:8px; overflow:hidden; }
        .langBtn {
          min-width:34px; border:0; border-right:1px solid rgba(255,255,255,.16); background:#252a35;
          color:#fff; padding:5px 7px; cursor:pointer; font:600 11px Arial,sans-serif;
        }
        .langBtn:last-child { border-right:0; }
        .langBtn.active { background:#f1f3f5; color:#12151b; }
        #close { border:0; background:transparent; color:#fff; font-size:24px; line-height:1; cursor:pointer; padding:0 3px; }
        .grid { display:grid; grid-template-columns:minmax(220px, 1fr) minmax(220px, 1fr); gap:16px; }
        .label { display:block; font-size:12px; opacity:.72; margin:0 0 5px; }
        select { width:100%; min-height:38px; border-radius:9px; border:1px solid rgba(255,255,255,.22); background:#252a35; color:#fff; padding:7px 9px; font:inherit; }
        select:disabled { opacity:.62; cursor:not-allowed; background:#343842; color:#c9cbd1; }
        .zoomRow { display:grid; grid-template-columns:1fr auto auto; align-items:center; gap:9px; margin-top:7px; }
        input[type=range] { width:100%; accent-color:#f2f2f2; }
        #zoomValue { min-width:45px; text-align:right; font-weight:700; }
        #resetZoom { border:1px solid rgba(255,255,255,.22); border-radius:8px; background:#252a35; color:#fff; padding:6px 8px; cursor:pointer; font:inherit; }
        .meta { border-left:1px solid rgba(255,255,255,.14); padding-left:16px; min-height:112px; }
        #metaName { font-size:16px; font-weight:700; margin-bottom:9px; overflow-wrap:anywhere; }
        .metaRow { display:grid; grid-template-columns:86px 1fr; gap:8px; margin:5px 0; }
        .metaKey { opacity:.68; }
        .metaVal { font-weight:600; overflow-wrap:anywhere; }
        #mode { margin-top:11px; font-size:11px; opacity:.48; }
        @media (max-width: 620px) {
          .grid { grid-template-columns:1fr; }
          .meta { border-left:0; border-top:1px solid rgba(255,255,255,.14); padding:12px 0 0; }
        }
      </style>
      <button id="eye" type="button">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6S2.5 12 2.5 12Z"></path><circle cx="12" cy="12" r="2.8"></circle></svg>
      </button>
      <div id="panel">
        <div class="header">
          <div class="title" id="uiTitle">Autodarts Theme</div>
          <div class="headerActions">
            <div class="langSwitch" aria-label="Language">
              <button class="langBtn" id="langDe" type="button">DE</button>
              <button class="langBtn" id="langEn" type="button">EN</button>
            </div>
            <button id="close" type="button">×</button>
          </div>
        </div>
        <div class="grid">
          <div>
            <label class="label" id="themeLabel" for="themeSelect">Theme</label>
            <select id="themeSelect"></select>
            <label class="label" id="zoomLabel" for="zoomRange" style="margin-top:14px;">Browser-Zoom</label>
            <div class="zoomRow">
              <input id="zoomRange" type="range" min="50" max="150" step="5" value="100">
              <span id="zoomValue">100 %</span>
              <button id="resetZoom" type="button">100%</button>
            </div>
            <div id="mode"></div>
          </div>
          <div class="meta">
            <div id="metaName">—</div>
            <div class="metaRow"><div class="metaKey" id="authorKey">Autor:</div><div class="metaVal" id="metaAuthor">—</div></div>
            <div class="metaRow"><div class="metaKey" id="modesKey">Spielmodi:</div><div class="metaVal" id="metaModes">—</div></div>
            <div class="metaRow"><div class="metaKey" id="resolutionKey">Auflösung:</div><div class="metaVal" id="metaResolution">—</div></div>
          </div>
        </div>
      </div>`;

    const eye = controlShadow.getElementById('eye');
    const panel = controlShadow.getElementById('panel');
    const close = controlShadow.getElementById('close');
    const select = controlShadow.getElementById('themeSelect');
    const zoom = controlShadow.getElementById('zoomRange');
    const reset = controlShadow.getElementById('resetZoom');
    const langDe = controlShadow.getElementById('langDe');
    const langEn = controlShadow.getElementById('langEn');

    let dragPointerId = null;
    let dragStartX = 0;
    let dragStartY = 0;
    let dragStartLeft = 0;
    let dragStartTop = 0;
    let dragMoved = false;

    eye.addEventListener('pointerdown', (event) => {
      if (event.pointerType === 'mouse' && event.button !== 0) return;
      const rect = eye.getBoundingClientRect();
      dragPointerId = event.pointerId;
      dragStartX = event.clientX;
      dragStartY = event.clientY;
      dragStartLeft = rect.left;
      dragStartTop = rect.top;
      dragMoved = false;
      eye.classList.add('dragging');
      try { eye.setPointerCapture(event.pointerId); } catch (_) {}
    });

    eye.addEventListener('pointermove', (event) => {
      if (dragPointerId !== event.pointerId) return;
      const dx = event.clientX - dragStartX;
      const dy = event.clientY - dragStartY;
      if (!dragMoved && Math.hypot(dx, dy) >= 5) dragMoved = true;
      if (!dragMoved) return;

      if (event.cancelable) event.preventDefault();
      const m = eyeMetrics();
      const left = clamp(dragStartLeft + dx, m.margin, m.maxX);
      const top = clamp(dragStartTop + dy, m.margin, m.maxY);
      eye.style.left = `${Math.round(left)}px`;
      eye.style.top = `${Math.round(top)}px`;
    });

    const finishDrag = async (event) => {
      if (dragPointerId !== event.pointerId) return;
      try { eye.releasePointerCapture(event.pointerId); } catch (_) {}
      dragPointerId = null;
      eye.classList.remove('dragging');

      if (dragMoved) {
        suppressEyeClick = true;
        // Chromium normally emits a click after pointerup even after a drag.
        // The short fallback reset prevents the *next* real click from being
        // swallowed on builds/devices where that synthetic click is omitted.
        window.setTimeout(() => { suppressEyeClick = false; }, 300);
        const rect = eye.getBoundingClientRect();
        await saveControlPosition(rect.left, rect.top);
      }
    };

    eye.addEventListener('pointerup', finishDrag);
    eye.addEventListener('pointercancel', finishDrag);
    eye.addEventListener('dragstart', (event) => event.preventDefault());

    eye.addEventListener('click', () => {
      if (suppressEyeClick) {
        suppressEyeClick = false;
        return;
      }
      panel.classList.add('open');
      requestAnimationFrame(() => {
        positionOpenPanel();
        eye.classList.add('hidden');
      });
      refreshControlUi();
    });

    close.addEventListener('click', () => {
      panel.classList.remove('open');
      eye.classList.remove('hidden');
    });

    langDe.addEventListener('click', () => setUiLanguage('de'));
    langEn.addEventListener('click', () => setUiLanguage('en'));

    select.addEventListener('change', async () => {
      const result = await sendMessage({ type: 'autodarts-theme:select-local', selected: select.value });
      if (!result || !result.ok) {
        debug('local theme selection failed', result?.error || 'unknown');
      }
      await refreshControlUi();
    });

    // While dragging, only the percentage label changes. Chromium's real tab
    // zoom is applied after the slider is released, with a short delay. This
    // prevents the page from moving underneath the mouse while the user drags.
    zoom.addEventListener('input', () => {
      if (zoomApplyTimer) {
        window.clearTimeout(zoomApplyTimer);
        zoomApplyTimer = null;
      }
      const value = Number(zoom.value || 100);
      updateZoomLabel(value / 100);
    });

    zoom.addEventListener('change', () => {
      if (zoomApplyTimer) window.clearTimeout(zoomApplyTimer);
      const value = Number(zoom.value || 100);
      updateZoomLabel(value / 100);
      zoomApplyTimer = window.setTimeout(async () => {
        zoomApplyTimer = null;
        await sendMessage({ type: 'autodarts-theme:set-zoom', zoom: value / 100 });
        positionOpenPanel();
      }, ZOOM_APPLY_DELAY_MS);
    });

    reset.addEventListener('click', async () => {
      if (zoomApplyTimer) {
        window.clearTimeout(zoomApplyTimer);
        zoomApplyTimer = null;
      }
      zoom.value = '100';
      updateZoomLabel(1);
      await sendMessage({ type: 'autodarts-theme:set-zoom', zoom: 1 });
      positionOpenPanel();
    });

    window.addEventListener('resize', applyControlPosition, { passive: true });
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', applyControlPosition, { passive: true });
    }

    applyControlPosition();
    applyUiLanguage();
    loadControlPreferences().catch(() => {});
  }

  function updateZoomLabel(zoom) {
    if (!controlShadow) return;
    const value = Math.round((Number(zoom) || 1) * 100);
    const valueEl = controlShadow.getElementById('zoomValue');
    const rangeEl = controlShadow.getElementById('zoomRange');
    if (valueEl) valueEl.textContent = `${value} %`;
    if (rangeEl && document.activeElement !== rangeEl) rangeEl.value = String(value);
  }

  function renderControlState(state) {
    ensureControlUi();
    if (!controlHost || !controlShadow) return;

    lastUiState = state || null;
    if (!state) {
      controlHost.style.display = 'block';
      return;
    }
    controlHost.style.display = 'block';

    const t = uiTexts();
    const select = controlShadow.getElementById('themeSelect');
    const themes = Array.isArray(state.themes) ? state.themes : [];
    const legacyMeta = state.legacyMeta && typeof state.legacyMeta === 'object' ? state.legacyMeta : null;
    const legacyThemeActive = state.mode === 'legacy' && String(state.selected || 'default') !== 'default';

    // No synchronized library yet. If the user explicitly activated a theme in
    // the web panel, still show that theme and any metadata the old/new panel
    // exposed in its existing <option data-...> fields. It is display-only.
    if (!state.hasLibrary || !themes.length) {
      select.innerHTML = '';
      const option = document.createElement('option');
      if (legacyThemeActive) {
        option.value = String(state.selected || legacyMeta?.id || '');
        option.textContent = legacyMeta?.name || String(state.selected || '');
        option.selected = true;
        option.disabled = false;
        select.appendChild(option);
        select.disabled = true;

        const unknown = t.unknown;
        controlShadow.getElementById('metaName').textContent = legacyMeta?.name || option.textContent || '—';
        controlShadow.getElementById('metaAuthor').textContent = legacyMeta?.author || unknown;
        controlShadow.getElementById('metaModes').textContent = legacyMeta?.modes || unknown;
        controlShadow.getElementById('metaResolution').textContent = legacyMeta?.resolution || unknown;
        controlShadow.getElementById('mode').textContent = t.legacyActive;
      } else {
        option.value = '';
        option.textContent = t.noThemes;
        option.selected = true;
        option.disabled = true;
        select.appendChild(option);
        select.disabled = true;

        controlShadow.getElementById('metaName').textContent = t.noThemes;
        controlShadow.getElementById('metaAuthor').textContent = '—';
        controlShadow.getElementById('metaModes').textContent = '—';
        controlShadow.getElementById('metaResolution').textContent = '—';
        controlShadow.getElementById('mode').textContent = t.legacy;
      }
      updateZoomLabel(state.zoom || 1);
      return;
    }

    // Rebuild the list on each render so translated labels stay correct.
    select.innerHTML = '';
    themes.forEach((theme) => {
      const option = document.createElement('option');
      option.value = theme.id;
      option.textContent = theme.id === 'default' ? t.defaultName : (theme.name || theme.id);
      select.appendChild(option);
    });

    let selected = themes.find((theme) => theme.id === state.selected) || null;

    // A legacy web-panel theme may not exist in an older synchronized library.
    // Add one display-only option so the active web-panel selection is still
    // visible instead of silently showing another browser theme.
    if (legacyThemeActive && !selected) {
      selected = {
        id: String(state.selected || legacyMeta?.id || ''),
        name: legacyMeta?.name || String(state.selected || ''),
        author: legacyMeta?.author || '',
        modes: legacyMeta?.modes || '',
        resolution: legacyMeta?.resolution || ''
      };
      const option = document.createElement('option');
      option.value = selected.id;
      option.textContent = selected.name || selected.id;
      select.appendChild(option);
    }

    if (!selected) selected = themes[0];
    if (selected) select.value = selected.id;

    // When a real theme was activated through the web panel, the dropdown is
    // intentionally locked/grey. Set "Default (off)" in the web panel to hand
    // control back to the browser dropdown. Zoom always remains available.
    select.disabled = legacyThemeActive;

    const unknown = t.unknown;
    controlShadow.getElementById('metaName').textContent = selected?.id === 'default' ? t.defaultName : (selected?.name || '—');
    controlShadow.getElementById('metaAuthor').textContent = selected?.author || (legacyThemeActive ? legacyMeta?.author : '') || unknown;
    controlShadow.getElementById('metaModes').textContent = selected?.modes || (legacyThemeActive ? legacyMeta?.modes : '') || unknown;
    controlShadow.getElementById('metaResolution').textContent = selected?.resolution || (legacyThemeActive ? legacyMeta?.resolution : '') || unknown;
    controlShadow.getElementById('mode').textContent = legacyThemeActive ? t.legacyActive : (state.mode === 'local' ? t.local : t.legacy);
    updateZoomLabel(state.zoom || 1);
  }

  async function refreshControlUi() {
    const state = await sendMessage({ type: 'autodarts-theme:get-ui-state' });
    if (state && state.ok) renderControlState(state);
  }

  async function applySavedZoom() {
    const state = await sendMessage({ type: 'autodarts-theme:get-ui-state' });
    if (!state || !state.ok) return;
    renderControlState(state);
    await sendMessage({ type: 'autodarts-theme:set-zoom', zoom: state.zoom || 1 });
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;
    if (changes[STORAGE_CSS_KEY]) {
      applyCss(changes[STORAGE_CSS_KEY].newValue || '', changes[STORAGE_SOURCE_KEY]?.newValue || lastAppliedSource);
    }
    if (changes[STORAGE_LANG_KEY]) {
      currentUiLanguage = normalizeUiLanguage(changes[STORAGE_LANG_KEY].newValue || 'de');
      applyUiLanguage();
    }
    if (changes[STORAGE_POS_KEY]) {
      controlPosition = normalizedPosition(changes[STORAGE_POS_KEY].newValue);
      applyControlPosition();
    }
    if (
      changes[STORAGE_LIBRARY_KEY] ||
      changes[STORAGE_SELECTED_KEY] ||
      changes[STORAGE_MODE_KEY] ||
      changes[STORAGE_ZOOM_KEY]
    ) {
      refreshControlUi().catch((error) => debug('control refresh failed', error));
    }
  });

  document.addEventListener('DOMContentLoaded', () => {
    scheduleBurst('domcontentloaded');
    refreshControlUi().catch(() => {});
  });
  window.addEventListener('load', () => {
    scheduleBurst('load');
    applySavedZoom().catch(() => {});
  });
  window.addEventListener('pageshow', () => {
    startObservers();
    scheduleBurst('pageshow');
    refreshControlUi().catch(() => {});
  });
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      scheduleBurst('visibility');
      refreshControlUi().catch(() => {});
    }
  });

  patchHistoryNavigation();
  startObservers();

  loadCachedCss().then((cached) => {
    if (cached.css) {
      applyCss(cached.css, cached.sourceUrl);
    } else {
      ensureStyleElement();
      keepStyleLast();
    }
    scheduleBurst('startup');
    refreshControlUi().catch(() => {});
  });
})();
