const THEME_URLS = [
  'http://10.77.0.1/api/autodarts-theme.css',
  'http://127.0.0.1/api/autodarts-theme.css',
  'http://localhost/api/autodarts-theme.css'
];

const STORAGE_CSS_KEY = 'autodartsThemeCachedCss';
const STORAGE_SOURCE_KEY = 'autodartsThemeCachedSource';
const STORAGE_TS_KEY = 'autodartsThemeCachedAt';
const STORAGE_LIBRARY_KEY = 'autodartsThemeLibraryV1';
const STORAGE_SELECTED_KEY = 'autodartsThemeSelectedId';
const STORAGE_MODE_KEY = 'autodartsThemeControlMode';
const STORAGE_ZOOM_KEY = 'autodartsThemeZoom';
const STORAGE_LEGACY_META_KEY = 'autodartsThemeLegacyActiveV1';
const MIN_REFRESH_INTERVAL_MS = 1200;
const PANEL_HOSTS = new Set(['10.77.0.1', '127.0.0.1', 'localhost']);

let memoryCss = '';
let memorySource = '';
let memoryLoaded = false;
let lastRefreshAt = 0;
let inflightPromise = null;

function debug(...args) {
  console.debug('Autodarts Themes BG:', ...args);
}

function normalizeCss(cssText) {
  return String(cssText || '').replace(/^\uFEFF/, '').trim();
}

function resolveCssUrls(cssText, baseUrl) {
  if (!cssText || !baseUrl) return cssText || '';

  return cssText.replace(/url\(([^)]+)\)/gi, (fullMatch, rawUrl) => {
    const trimmed = String(rawUrl || '').trim().replace(/^['"]|['"]$/g, '');
    if (!trimmed) return fullMatch;

    const lower = trimmed.toLowerCase();
    if (
      lower.startsWith('data:') ||
      lower.startsWith('blob:') ||
      lower.startsWith('chrome-extension:') ||
      lower.startsWith('moz-extension:') ||
      lower.startsWith('about:') ||
      lower.startsWith('http://') ||
      lower.startsWith('https://') ||
      lower.startsWith('//')
    ) {
      return `url("${trimmed}")`;
    }

    try {
      return `url("${new URL(trimmed, baseUrl).href}")`;
    } catch (error) {
      debug('URL rewrite failed for', trimmed, error);
      return fullMatch;
    }
  });
}

async function loadMemoryCache() {
  if (memoryLoaded) return;
  try {
    const data = await chrome.storage.local.get([STORAGE_CSS_KEY, STORAGE_SOURCE_KEY, STORAGE_TS_KEY]);
    memoryCss = normalizeCss(data[STORAGE_CSS_KEY] || '');
    memorySource = typeof data[STORAGE_SOURCE_KEY] === 'string' ? data[STORAGE_SOURCE_KEY] : '';
    lastRefreshAt = Number(data[STORAGE_TS_KEY] || 0);
  } catch (error) {
    console.warn('Autodarts Themes: unable to load cached CSS', error);
  }
  memoryLoaded = true;
}

async function saveMemoryCache(css, sourceUrl) {
  memoryCss = normalizeCss(css);
  memorySource = sourceUrl || '';
  lastRefreshAt = Date.now();
  await chrome.storage.local.set({
    [STORAGE_CSS_KEY]: memoryCss,
    [STORAGE_SOURCE_KEY]: memorySource,
    [STORAGE_TS_KEY]: lastRefreshAt
  });
}

async function tryFetchUrl(url) {
  const response = await fetch(url, {
    cache: 'no-store',
    redirect: 'follow'
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const rawCss = await response.text();
  const css = normalizeCss(resolveCssUrls(rawCss, url));
  return { ok: true, css, sourceUrl: url, fromCache: false, authoritative: true };
}

async function fetchFreshCss(force = false) {
  await loadMemoryCache();

  if (inflightPromise) {
    return inflightPromise;
  }

  if (!force && Date.now() - lastRefreshAt < MIN_REFRESH_INTERVAL_MS) {
    return { ok: true, css: memoryCss, sourceUrl: memorySource, fromCache: true, authoritative: true };
  }

  inflightPromise = (async () => {
    let lastError = null;

    for (const url of THEME_URLS) {
      try {
        const result = await tryFetchUrl(url);
        if (result.css !== memoryCss || result.sourceUrl !== memorySource) {
          await saveMemoryCache(result.css, result.sourceUrl);
        } else {
          lastRefreshAt = Date.now();
          await chrome.storage.local.set({ [STORAGE_TS_KEY]: lastRefreshAt });
        }
        return result;
      } catch (error) {
        lastError = error;
        debug('fetch failed for', url, error);
      }
    }

    if (memoryCss) {
      return { ok: true, css: memoryCss, sourceUrl: memorySource, fromCache: true, stale: true, authoritative: false };
    }

    return {
      ok: false,
      css: memoryCss,
      sourceUrl: memorySource,
      fromCache: true,
      stale: true,
      authoritative: false,
      error: String(lastError?.message || lastError || 'No theme URL succeeded')
    };
  })().finally(() => {
    inflightPromise = null;
  });

  return inflightPromise;
}

function normalizePanelOrigin(baseUrl) {
  const parsed = new URL(String(baseUrl || ''));
  if (parsed.protocol !== 'http:' || !PANEL_HOSTS.has(parsed.hostname)) {
    throw new Error('Unsupported web panel origin');
  }
  return parsed.origin;
}

function normalizeThemeEntry(raw, panelOrigin) {
  if (!raw || typeof raw !== 'object') return null;
  const filename = String(raw.filename || '').trim();
  if (!filename) return null;
  const cssBase = `${panelOrigin}/api/autodarts-theme.css`;
  return {
    id: filename,
    filename,
    name: String(raw.name || filename.replace(/\.css$/i, '')).trim(),
    author: String(raw.author || '').trim(),
    modes: String(raw.modes || '').trim(),
    resolution: String(raw.resolution || '').trim(),
    css: normalizeCss(resolveCssUrls(String(raw.css || ''), cssBase))
  };
}

async function syncThemeLibrary(baseUrl) {
  const panelOrigin = normalizePanelOrigin(baseUrl);
  const response = await fetch(`${panelOrigin}/api/autodarts-theme/sync`, {
    cache: 'no-store',
    redirect: 'follow'
  });
  if (!response.ok) {
    throw new Error(`Sync API HTTP ${response.status}`);
  }

  const payload = await response.json();
  if (!payload || payload.ok !== true || !Array.isArray(payload.themes)) {
    throw new Error('Ungültige Sync-Antwort des Webpanels');
  }

  const themes = payload.themes
    .map((item) => normalizeThemeEntry(item, panelOrigin))
    .filter(Boolean);

  if (!themes.some((item) => item.id === 'default')) {
    themes.unshift({
      id: 'default',
      filename: 'default',
      name: 'Default (aus)',
      author: '',
      modes: '',
      resolution: '',
      css: ''
    });
  }

  const selectedCandidate = String(payload.selected || 'default').trim() || 'default';
  const selected = themes.some((item) => item.id === selectedCandidate) ? selectedCandidate : 'default';
  const now = Date.now();

  // A successful explicit library sync from the NEW web panel hands theme
  // control to the browser. Keep the currently selected web-panel theme as
  // the selected local theme, but unlock the dropdown immediately.
  // Old web panels never call this sync action, so their legacy workflow
  // remains unchanged. Clicking the classic "Theme aktivieren" button later
  // switches back to legacy/webpanel mode through panel-bridge.js.
  await chrome.storage.local.set({
    [STORAGE_LIBRARY_KEY]: {
      schema: 1,
      panelOrigin,
      syncedAt: now,
      themes
    },
    [STORAGE_SELECTED_KEY]: selected,
    [STORAGE_MODE_KEY]: 'local'
  });

  return {
    ok: true,
    count: Math.max(0, themes.length - 1),
    selected,
    panelOrigin,
    syncedAt: now
  };
}

function getThemeFromLibrary(library, selected) {
  const themes = library && Array.isArray(library.themes) ? library.themes : [];
  return themes.find((item) => item && item.id === selected) || null;
}

function normalizeLegacyMeta(raw, selectedId = 'default') {
  const id = String(selectedId || raw?.id || 'default').trim() || 'default';
  const meta = raw && typeof raw === 'object' ? raw : {};
  return {
    id,
    name: String(meta.name || (id === 'default' ? 'Default (aus)' : id.replace(/\.css$/i, ''))).trim(),
    author: String(meta.author || '').trim(),
    modes: String(meta.modes || '').trim(),
    resolution: String(meta.resolution || '').trim()
  };
}

async function getUiState() {
  const data = await chrome.storage.local.get([
    STORAGE_LIBRARY_KEY,
    STORAGE_SELECTED_KEY,
    STORAGE_MODE_KEY,
    STORAGE_ZOOM_KEY,
    STORAGE_LEGACY_META_KEY
  ]);
  const library = data[STORAGE_LIBRARY_KEY];
  const themes = library && Array.isArray(library.themes) ? library.themes : [];
  const selectedRaw = String(data[STORAGE_SELECTED_KEY] || 'default').trim() || 'default';
  const mode = data[STORAGE_MODE_KEY] === 'local' ? 'local' : 'legacy';
  const selected = mode === 'local'
    ? (themes.some((item) => item.id === selectedRaw) ? selectedRaw : (themes[0]?.id || 'default'))
    : selectedRaw;
  const zoom = Math.min(1.5, Math.max(0.5, Number(data[STORAGE_ZOOM_KEY] || 1) || 1));
  const legacyMeta = normalizeLegacyMeta(data[STORAGE_LEGACY_META_KEY], selectedRaw);

  return {
    ok: true,
    hasLibrary: themes.length > 0,
    selected,
    mode,
    legacyMeta,
    zoom,
    syncedAt: Number(library?.syncedAt || 0),
    panelOrigin: String(library?.panelOrigin || ''),
    themes: themes.map((item) => ({
      id: item.id,
      filename: item.filename,
      name: item.name,
      author: item.author,
      modes: item.modes,
      resolution: item.resolution
    }))
  };
}

async function selectLocalTheme(selected) {
  const data = await chrome.storage.local.get([STORAGE_LIBRARY_KEY]);
  const library = data[STORAGE_LIBRARY_KEY];
  const theme = getThemeFromLibrary(library, String(selected || '').trim());
  if (!theme) {
    throw new Error('Theme ist nicht im Browser synchronisiert.');
  }

  const source = `local-theme://${encodeURIComponent(theme.id)}`;
  await chrome.storage.local.set({
    [STORAGE_SELECTED_KEY]: theme.id,
    [STORAGE_MODE_KEY]: 'local'
  });
  await saveMemoryCache(theme.css || '', source);

  return {
    ok: true,
    selected: theme.id,
    theme: {
      id: theme.id,
      filename: theme.filename,
      name: theme.name,
      author: theme.author,
      modes: theme.modes,
      resolution: theme.resolution
    }
  };
}

async function switchToLegacySelection(selected, metadata = null) {
  const selectedId = String(selected || 'default').trim() || 'default';
  const legacyMeta = normalizeLegacyMeta(metadata, selectedId);
  await chrome.storage.local.set({
    [STORAGE_SELECTED_KEY]: selectedId,
    [STORAGE_MODE_KEY]: 'legacy',
    [STORAGE_LEGACY_META_KEY]: legacyMeta
  });
  return fetchFreshCss(true);
}

async function getCurrentCss(force = false) {
  const data = await chrome.storage.local.get([
    STORAGE_LIBRARY_KEY,
    STORAGE_SELECTED_KEY,
    STORAGE_MODE_KEY
  ]);

  if (data[STORAGE_MODE_KEY] === 'local') {
    const selected = String(data[STORAGE_SELECTED_KEY] || 'default').trim() || 'default';
    const theme = getThemeFromLibrary(data[STORAGE_LIBRARY_KEY], selected);
    if (theme) {
      const css = normalizeCss(theme.css || '');
      const sourceUrl = `local-theme://${encodeURIComponent(theme.id)}`;
      if (css !== memoryCss || sourceUrl !== memorySource) {
        await saveMemoryCache(css, sourceUrl);
      }
      return { ok: true, css, sourceUrl, fromCache: true, local: true, authoritative: true };
    }
  }

  return fetchFreshCss(force);
}

async function setTabZoom(sender, rawZoom) {
  const zoom = Math.min(1.5, Math.max(0.5, Number(rawZoom) || 1));
  await chrome.storage.local.set({ [STORAGE_ZOOM_KEY]: zoom });
  if (sender && sender.tab && Number.isInteger(sender.tab.id)) {
    await chrome.tabs.setZoom(sender.tab.id, zoom);
  }
  return { ok: true, zoom };
}

chrome.runtime.onInstalled.addListener(() => {
  loadMemoryCache().catch(() => {});
});

chrome.runtime.onStartup?.addListener(() => {
  loadMemoryCache().catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== 'string') {
    return false;
  }

  let task = null;

  if (message.type === 'autodarts-theme:refresh-css') {
    task = getCurrentCss(Boolean(message.force));
  } else if (message.type === 'autodarts-theme:sync-library') {
    task = syncThemeLibrary(message.baseUrl);
  } else if (message.type === 'autodarts-theme:legacy-select') {
    task = switchToLegacySelection(message.selected, message.metadata);
  } else if (message.type === 'autodarts-theme:get-ui-state') {
    task = getUiState();
  } else if (message.type === 'autodarts-theme:select-local') {
    task = selectLocalTheme(message.selected);
  } else if (message.type === 'autodarts-theme:set-zoom') {
    task = setTabZoom(sender, message.zoom);
  } else {
    return false;
  }

  Promise.resolve(task)
    .then((result) => sendResponse(result))
    .catch((error) => {
      console.warn('Autodarts Themes BG:', message.type, 'failed', error);
      sendResponse({
        ok: false,
        error: String(error?.message || error)
      });
    });

  return true;
});
