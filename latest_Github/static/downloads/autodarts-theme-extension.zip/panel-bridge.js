(() => {
  const SOURCE_PANEL = 'autodarts-theme-webpanel';
  const SOURCE_EXTENSION = 'autodarts-theme-extension';


  function selectedMetadata() {
    const select = document.getElementById('autodartsThemeSelect');
    const option = select?.selectedOptions?.[0] || null;
    const selected = String(select?.value || 'default').trim() || 'default';
    return {
      id: selected,
      name: String(option?.textContent || '').trim(),
      author: String(option?.dataset?.author || '').trim(),
      modes: String(option?.dataset?.modes || '').trim(),
      resolution: String(option?.dataset?.resolution || '').trim()
    };
  }

  function reply(requestId, action, response) {
    window.postMessage({
      source: SOURCE_EXTENSION,
      requestId: requestId || '',
      action,
      response: response || { ok: false, error: 'Keine Antwort der Extension.' }
    }, location.origin);
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const data = event.data;
    if (!data || data.source !== SOURCE_PANEL) return;

    const requestId = String(data.requestId || '');

    if (data.action === 'sync-library') {
      chrome.runtime.sendMessage({
        type: 'autodarts-theme:sync-library',
        baseUrl: location.origin
      }, (response) => {
        if (chrome.runtime.lastError) {
          reply(requestId, data.action, { ok: false, error: chrome.runtime.lastError.message });
          return;
        }
        reply(requestId, data.action, response);
      });
      return;
    }

    if (data.action === 'legacy-select') {
      chrome.runtime.sendMessage({
        type: 'autodarts-theme:legacy-select',
        selected: String(data.selected || 'default'),
        metadata: data.metadata && typeof data.metadata === 'object' ? data.metadata : selectedMetadata()
      }, (response) => {
        if (chrome.runtime.lastError) {
          reply(requestId, data.action, { ok: false, error: chrome.runtime.lastError.message });
          return;
        }
        reply(requestId, data.action, response);
      });
    }
  });

  // Backward compatibility for older web panels that know nothing about
  // the bridge: if their classic "Theme aktivieren" button is clicked, switch
  // the extension back to legacy/webpanel mode and refresh the active CSS.
  document.addEventListener('click', (event) => {
    const target = event.target instanceof Element ? event.target : null;
    const applyButton = target?.closest?.('#autodartsThemeApplyBtn');
    if (!applyButton) return;

    window.setTimeout(() => {
      const metadata = selectedMetadata();
      chrome.runtime.sendMessage({
        type: 'autodarts-theme:legacy-select',
        selected: metadata.id,
        metadata
      }, () => void chrome.runtime.lastError);
    }, 700);
  }, true);

  // Lets the new web panel detect that a compatible extension is present.
  window.postMessage({
    source: SOURCE_EXTENSION,
    action: 'bridge-ready',
    response: { ok: true }
  }, location.origin);
})();
