Autodarts Themes 1.5.2

Chrome Web Store upload package.

Compatibility:
- play.autodarts.io
- play.autodarts.com
- old web panels: keeps using /api/autodarts-theme.css exactly as before
- new web panels: optional "Alle Themes synchronisieren" bridge

Features:
- eye control is always visible, even before theme synchronization
- eye can be dragged freely around the viewport with mouse or touch
- position is stored and restored; it is clamped after resize/browser zoom so it cannot remain off-screen
- DE / EN switch in the panel; language is stored locally
- synchronized themes stay stored in the browser
- changing the dropdown applies the selected theme immediately
- metadata (author, game modes, resolution) is shown next to the selector
- live browser zoom slider, stored per browser
- legacy "Theme aktivieren" workflow remains available

Preview images are intentionally NOT synchronized.


Version 1.5.4:
- Webpanel-aktiviertes Theme wird im Auge-Panel angezeigt, Dropdown dabei gesperrt/grau.
- Metadaten werden beim klassischen Theme-aktivieren aus bestehenden Option-Daten übernommen.
- Dropdown wird wieder nutzbar, wenn im Webpanel Default (aus) aktiv ist und eine Theme-Library synchronisiert wurde.
- Zoom wird beim Ziehen nur angezeigt und erst 350 ms nach Loslassen angewendet (Chromium-stabil).

1.5.4:
- Nach erfolgreichem "Alle Themes synchronisieren" wechselt die Extension bewusst in Browser-Modus.
- Das aktuell im Webpanel gewählte Theme bleibt ausgewählt, aber das Dropdown auf Autodarts wird sofort freigeschaltet.
- Alter Webpanel-Workflow bleibt unverändert; ein späterer Klick auf "Theme aktivieren" schaltet wieder in Webpanel-Modus.
