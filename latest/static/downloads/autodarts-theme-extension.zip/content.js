(() => {
  const STYLE_ID = 'autodarts-theme-style';
  const STORAGE_CSS_KEY = 'autodartsThemeCachedCss';
  const STORAGE_SOURCE_KEY = 'autodartsThemeCachedSource';
  const APPLY_INTERVAL_MS = 10000;
  const RETRY_DELAYS_MS = [0, 80, 250, 700, 1500, 3200];

  let lastAppliedCss = '';
  let lastAppliedSource = '';
  let lastKnownHref = location.href;
  let refreshTimer = null;
  let observer = null;
  let navPatched = false;

  function debug(...args) {
    console.debug('Autodarts Themes:', ...args);
  }

  function getTargetNode() {
    return document.head || document.documentElement;
  }

  function ensureStyleElement() {
    let styleEl = document.getElementById(STYLE_ID);
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = STYLE_ID;
      styleEl.type = 'text/css';
      styleEl.setAttribute('data-autodarts-theme', 'active');
    }

    const target = getTargetNode();
    if (target && styleEl.parentNode !== target) {
      target.appendChild(styleEl);
    }

    return styleEl;
  }

  function keepStyleLast() {
    const target = getTargetNode();
    const styleEl = document.getElementById(STYLE_ID);
    if (!target || !styleEl) return;

    if (target.lastElementChild !== styleEl) {
      target.appendChild(styleEl);
    }
  }

  function normalizeCss(cssText) {
    return String(cssText || '').replace(/^\uFEFF/, '').trim();
  }

  function applyCss(cssText, sourceUrl = '') {
    const normalized = normalizeCss(cssText);
    const styleEl = ensureStyleElement();

    if (styleEl.textContent !== normalized) {
      styleEl.textContent = normalized;
    }

    styleEl.setAttribute('data-source-url', sourceUrl || '');
    keepStyleLast();

    lastAppliedCss = normalized;
    lastAppliedSource = sourceUrl || '';
  }

  async function loadCachedCss() {
    try {
      const data = await chrome.storage.local.get([STORAGE_CSS_KEY, STORAGE_SOURCE_KEY]);
      return {
        css: normalizeCss(data[STORAGE_CSS_KEY] || ''),
        sourceUrl: typeof data[STORAGE_SOURCE_KEY] === 'string' ? data[STORAGE_SOURCE_KEY] : ''
      };
    } catch (error) {
      debug('cache read failed', error);
      return { css: '', sourceUrl: '' };
    }
  }

  function requestBackgroundCss(force = false) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: 'autodarts-theme:refresh-css', force }, (response) => {
          if (chrome.runtime.lastError) {
            debug('runtime message failed', chrome.runtime.lastError.message);
            resolve(null);
            return;
          }
          resolve(response || null);
        });
      } catch (error) {
        debug('sendMessage threw', error);
        resolve(null);
      }
    });
  }

  async function refreshTheme(force = false) {
    if (!force && lastAppliedCss) {
      applyCss(lastAppliedCss, lastAppliedSource);
    }

    const result = await requestBackgroundCss(force);

    if (result && typeof result.css === 'string') {
      applyCss(result.css, result.sourceUrl || '');
      return result;
    }

    const cached = await loadCachedCss();
    applyCss(cached.css, cached.sourceUrl);
    return { ok: true, css: cached.css, sourceUrl: cached.sourceUrl, fromCache: true, stale: true };
  }

  function scheduleBurst(reason) {
    RETRY_DELAYS_MS.forEach((delay) => {
      window.setTimeout(() => {
        refreshTheme(delay > 0).catch((error) => debug(`refresh failed after ${reason}`, error));
      }, delay);
    });
  }

  function startObservers() {
    if (!observer) {
      observer = new MutationObserver(() => {
        keepStyleLast();
        if (location.href !== lastKnownHref) {
          lastKnownHref = location.href;
          scheduleBurst('mutation-navigation');
        }
      });

      observer.observe(document.documentElement, {
        childList: true,
        subtree: true
      });
    }

    if (!refreshTimer) {
      refreshTimer = window.setInterval(() => {
        if (document.visibilityState === 'visible') {
          refreshTheme(true).catch((error) => debug('interval refresh failed', error));
        }
      }, APPLY_INTERVAL_MS);
    }
  }

  function patchHistoryNavigation() {
    if (navPatched) return;
    navPatched = true;

    const wrap = (original) => function wrappedHistoryMethod(...args) {
      const result = original.apply(this, args);
      window.setTimeout(() => {
        if (location.href !== lastKnownHref) {
          lastKnownHref = location.href;
          scheduleBurst('history-navigation');
        }
      }, 0);
      return result;
    };

    history.pushState = wrap(history.pushState);
    history.replaceState = wrap(history.replaceState);
    window.addEventListener('popstate', () => {
      if (location.href !== lastKnownHref) {
        lastKnownHref = location.href;
        scheduleBurst('popstate');
      }
    });
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;
    if (changes[STORAGE_CSS_KEY]) {
      applyCss(changes[STORAGE_CSS_KEY].newValue || '', changes[STORAGE_SOURCE_KEY]?.newValue || lastAppliedSource);
    }
  });

  document.addEventListener('DOMContentLoaded', () => scheduleBurst('domcontentloaded'));
  window.addEventListener('load', () => scheduleBurst('load'));
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      scheduleBurst('visibility');
    }
  });

  patchHistoryNavigation();
  startObservers();

  loadCachedCss().then((cached) => {
    if (cached.css) {
      applyCss(cached.css, cached.sourceUrl);
    } else {
      ensureStyleElement();
      keepStyleLast();
    }
    scheduleBurst('startup');
  });
})();
