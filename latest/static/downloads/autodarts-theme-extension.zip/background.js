const THEME_URLS = [
  'http://10.77.0.1/api/autodarts-theme.css',
  'http://127.0.0.1/api/autodarts-theme.css',
  'http://localhost/api/autodarts-theme.css'
];

const STORAGE_CSS_KEY = 'autodartsThemeCachedCss';
const STORAGE_SOURCE_KEY = 'autodartsThemeCachedSource';
const STORAGE_TS_KEY = 'autodartsThemeCachedAt';
const MIN_REFRESH_INTERVAL_MS = 1200;

let memoryCss = '';
let memorySource = '';
let memoryLoaded = false;
let lastRefreshAt = 0;
let inflightPromise = null;

function debug(...args) {
  console.debug('Autodarts Themes BG:', ...args);
}

function normalizeCss(cssText) {
  return String(cssText || '').replace(/^\uFEFF/, '').trim();
}

function resolveCssUrls(cssText, baseUrl) {
  if (!cssText || !baseUrl) return cssText || '';

  return cssText.replace(/url\(([^)]+)\)/gi, (fullMatch, rawUrl) => {
    const trimmed = String(rawUrl || '').trim().replace(/^['"]|['"]$/g, '');
    if (!trimmed) return fullMatch;

    const lower = trimmed.toLowerCase();
    if (
      lower.startsWith('data:') ||
      lower.startsWith('blob:') ||
      lower.startsWith('chrome-extension:') ||
      lower.startsWith('moz-extension:') ||
      lower.startsWith('about:') ||
      lower.startsWith('http://') ||
      lower.startsWith('https://') ||
      lower.startsWith('//')
    ) {
      return `url("${trimmed}")`;
    }

    try {
      return `url("${new URL(trimmed, baseUrl).href}")`;
    } catch (error) {
      debug('URL rewrite failed for', trimmed, error);
      return fullMatch;
    }
  });
}

async function loadMemoryCache() {
  if (memoryLoaded) return;
  try {
    const data = await chrome.storage.local.get([STORAGE_CSS_KEY, STORAGE_SOURCE_KEY, STORAGE_TS_KEY]);
    memoryCss = normalizeCss(data[STORAGE_CSS_KEY] || '');
    memorySource = typeof data[STORAGE_SOURCE_KEY] === 'string' ? data[STORAGE_SOURCE_KEY] : '';
    lastRefreshAt = Number(data[STORAGE_TS_KEY] || 0);
  } catch (error) {
    console.warn('Autodarts Themes: unable to load cached CSS', error);
  }
  memoryLoaded = true;
}

async function saveMemoryCache(css, sourceUrl) {
  memoryCss = normalizeCss(css);
  memorySource = sourceUrl || '';
  lastRefreshAt = Date.now();
  await chrome.storage.local.set({
    [STORAGE_CSS_KEY]: memoryCss,
    [STORAGE_SOURCE_KEY]: memorySource,
    [STORAGE_TS_KEY]: lastRefreshAt
  });
}

async function tryFetchUrl(url) {
  const response = await fetch(url, {
    cache: 'no-store',
    redirect: 'follow'
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const rawCss = await response.text();
  const css = normalizeCss(resolveCssUrls(rawCss, url));
  return { ok: true, css, sourceUrl: url, fromCache: false };
}

async function fetchFreshCss(force = false) {
  await loadMemoryCache();

  if (inflightPromise) {
    return inflightPromise;
  }

  if (!force && Date.now() - lastRefreshAt < MIN_REFRESH_INTERVAL_MS) {
    return { ok: true, css: memoryCss, sourceUrl: memorySource, fromCache: true };
  }

  inflightPromise = (async () => {
    let lastError = null;

    for (const url of THEME_URLS) {
      try {
        const result = await tryFetchUrl(url);
        if (result.css !== memoryCss || result.sourceUrl !== memorySource) {
          await saveMemoryCache(result.css, result.sourceUrl);
        } else {
          lastRefreshAt = Date.now();
          await chrome.storage.local.set({ [STORAGE_TS_KEY]: lastRefreshAt });
        }
        return result;
      } catch (error) {
        lastError = error;
        debug('fetch failed for', url, error);
      }
    }

    if (memoryCss) {
      return { ok: true, css: memoryCss, sourceUrl: memorySource, fromCache: true, stale: true };
    }

    throw lastError || new Error('No theme URL succeeded');
  })().finally(() => {
    inflightPromise = null;
  });

  return inflightPromise;
}

chrome.runtime.onInstalled.addListener(() => {
  loadMemoryCache().catch(() => {});
});

chrome.runtime.onStartup?.addListener(() => {
  loadMemoryCache().catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== 'autodarts-theme:refresh-css') {
    return false;
  }

  fetchFreshCss(Boolean(message.force))
    .then((result) => sendResponse(result))
    .catch((error) => {
      console.error('Autodarts Themes BG: unexpected background error', error);
      sendResponse({ ok: true, css: memoryCss, sourceUrl: memorySource, fromCache: true, stale: true, error: String(error?.message || error) });
    });

  return true;
});
